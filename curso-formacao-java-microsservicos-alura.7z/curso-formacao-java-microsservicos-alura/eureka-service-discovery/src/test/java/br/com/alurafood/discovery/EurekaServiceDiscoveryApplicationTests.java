package br.com.alurafood.discovery;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class EurekaServiceDiscoveryApplicationTests {

	@Test
	void contextLoads() {
	}

}
