package br.com.alurafood.pagamentos.domain.model;

public enum TipoPessoa {

    FISICA,
    JURIDICA

}
