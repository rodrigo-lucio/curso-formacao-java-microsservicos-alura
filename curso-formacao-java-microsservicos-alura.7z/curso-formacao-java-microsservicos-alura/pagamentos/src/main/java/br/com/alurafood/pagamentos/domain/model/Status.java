package br.com.alurafood.pagamentos.domain.model;

public enum Status {

    CRIADO,
    CONFIRMADO,
    CANCELADO

}
