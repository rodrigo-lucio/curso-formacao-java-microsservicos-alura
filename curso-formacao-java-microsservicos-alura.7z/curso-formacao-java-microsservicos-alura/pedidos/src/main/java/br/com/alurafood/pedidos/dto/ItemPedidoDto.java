package br.com.alurafood.pedidos.dto;

import java.util.UUID;

import lombok.*;

@Getter
@Setter
@AllArgsConstructor
@NoArgsConstructor
public class ItemPedidoDto {

    private UUID id;
    private Integer quantidade;
    private String descricao;
}
